CREATE VIEW Camion_Total_dech AS
SELECT p.plaqueCamion, SUM(q.nb_poubQuartier) AS total_dech
FROM Programmations p
JOIN Quartiers q USING(codeQuartier)
GROUP BY p.plaqueCamion;

